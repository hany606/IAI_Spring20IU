s(1,1).
h(1,1).
h(2,2).
h(3,3).
h(4,4).
o(1,2).
o(2,1).
o(2,3).
o(3,2).
o(3,4).
o(4,3).
o(4,5).
% o(5,4). % not solvable with this, when comment this only solvable in A*
t(5,5). 